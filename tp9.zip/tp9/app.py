class DatosMeteorologicos:
    def __init__(self, nombre_archivo: str):
        self.nombre_archivo = nombre_archivo

    def procesar_datos(self) -> tuple[float, float, float, float, str]:
        temperaturas_leidas = []
        humedades_leidas = []
        presiones_leidas = []
        vientos_leidos = []
        resultados = []

        with open("datos.txt", "r") as archivo:
            
            for linea in archivo:
                #temperatura
                if linea.startswith("Temperatura: "):
                    linea = float(linea[13:17])
                    temperaturas_leidas.append(linea)
                    suma = sum(temperaturas_leidas)
                    temperatura_promedio = suma/len(temperaturas_leidas)

                #humedad
                elif linea.startswith("Humedad: "):
                    linea = float(linea[9:13])
                    humedades_leidas.append(linea)
                    suma = sum(humedades_leidas)
                    humedad_promedio = suma/len(humedades_leidas)

                #presion
                elif linea.startswith("Presion: "):
                    linea = float(linea[8:15])
                    presiones_leidas.append(linea)
                    suma = sum(presiones_leidas)
                    presion_promedio = suma/len(presiones_leidas)
                
                #viento
                elif linea.startswith("Viento: "):
                    linea = linea.replace(",", " ")
                    linea = float(linea[8:12])
                    vientos_leidos.append(linea)
                    suma = sum(vientos_leidos)
                    viento_promedio = suma/len(vientos_leidos)

    
            resultados.append(temperatura_promedio)
            resultados.append(humedad_promedio)
            resultados.append(presion_promedio)
            resultados.append(viento_promedio)

            resultados = tuple(resultados)
            return resultados

print(DatosMeteorologicos.procesar_datos("datos.txt"))